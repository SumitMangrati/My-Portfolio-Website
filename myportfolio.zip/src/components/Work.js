import React from 'react'

function Work() {
  return (
    <div>
      No Work Experience Currently !!
    </div>
  )
}

export default Work