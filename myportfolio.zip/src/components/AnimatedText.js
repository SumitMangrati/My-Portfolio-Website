import React from 'react'
import "../styles/AnimatedText.css"
function AnimatedText() {
  return (
   <>
   <div className="text-body">
    <ul className="dynamic-text">
        <li><span>Student</span></li>
        <li><span>Developer</span></li>
        <li><span>Frontend Developer</span></li>
        <li><span>Musician</span></li>
    </ul>
   </div>
    
   </>
  )
}

export default AnimatedText
