import html from "../assets/html.png";
import css from "../assets/css.png";
import javascript from "../assets/javascript.png";
import react from "../assets/react.png";
import java from "../assets/java.png";

export const skillList=[
    {
        image:html,
        name:"HTML"
    },
    {
        image:css,
        name:"CSS"
    },
    {
        image:javascript,
        name:"Javascript"
    },
    {
        image:react,
        name:"React"
    },
    {
        image:java,
        name:"Java"
    }
];